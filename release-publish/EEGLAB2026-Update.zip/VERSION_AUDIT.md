# Version audit — upstream 13 November; QuickLab 19 November 2026

Desktop **1.4.0** retains **EEGLAB 2026.1.0**, the newest ZIP listed at the 13 November audit by the
[official publisher](https://sccn.ucsd.edu/eeglab/download/daily/).
At that audit, all 49 catalog-managed plugins from the 53-plugin inventory matched the
[current stable EEGLAB catalog](https://sccn.ucsd.edu/eeglab/plugin_uploader/plugin_list_all.php).
The additional bundled EEG-BIDS 10.5 also matched the catalog.
FieldTrip-lite 250523 and Fileio 260210 were the EEGLAB catalog packages;
development/nightly snapshots of the full FieldTrip toolbox are not substituted.
The 19 November update restores the lab's familiar QuickLab layout; it does not
change those third-party pins or claim a new audit of all upstream releases.

The four separately maintained entries are:

| Component | Selected source | Check |
| --- | --- | --- |
| QuickLab lab edition | MPG-Git/QuickLab, `22f659666c2d10ded1c9cd3cd192881f18d06a7c`, version 1.2.0 | This release's maintained comparison/menu code; registered as QuickLabMPG |
| NeuroLode | MPG-Git/NeuroLode, `0fc194d44330ba975346c3457da56d1fb00bce47` | Current main; hook 1.7.0 |
| CUDAICA for Windows | CloudyDory/cudaica_win, `02aaf9c36c0b12346bccdc25eec195565634abdd` | Current upstream HEAD; 1.1; GPU execution unverified |
| SPM | [Official MATLAB release 26.10.01](https://github.com/spm/spm/releases/tag/26.10.01) | Newest non-prerelease; replaces SPM12 r7771 |

RELAX's supplemental MWF dependency remains at current upstream HEAD
`85115641b36b711a4263eeb83f60e4706ea4e732` in exporl/mwf-artifact-removal.
The [manifest](manifest.json) contains archive URLs and SHA-256 checksums.
Current means the published sources checked on this date, not every upstream
development branch or every possible EEGLAB extension.

## Packaging adaptations

- Versioned folders supply missing metadata for AAR, Adjust, MARA, TBT,
  automagic, erppeakinterval, fullRankAveRef, std_dipoleDensity and trimOutlier.
- EYE-EEG's official 1.0.1 archive says `1.01` in its hook; the installer
  corrects that exact string, refusing an unexpected source/version.
- Fileio's `ft_defaults.m` is excluded because the complete FieldTrip-lite
  initializer is present. Every Fileio import/export function is retained.
  No warnings or upstream update checks are disabled.
- The lab fork has a distinct catalog identity, QuickLabMPG, while preserving
  the QuickLab menu and Infinity/Average comparison.

SPM's native M/EEG initializer adds its separate vendored FieldTrip and must
run in a separate clean MATLAB session. Its complete M/EEG workflow has not
been validated in this bundle. See [validation](VALIDATION.md) for test scope.

The supplemental Windows BINICA runtime is pinned to official SCCN commit `ec0004fd64213ca51290eff38636237e706b38b5` (no tagged releases published). The EXE and adjacent OpenBLAS DLL were exercised on full- and reduced-rank synthetic data; user setup of `icadefs.m` is unnecessary for QuickLab.

REST 1.2 now uses the complete official SCCN source at `ab9106d127f545f711ffb157eb0fb002a02a8552` (checked 19 November), including the `dong_getleadfield` and `dong_rest_refer` functions called by its GUI. The former catalog ZIP omitted these functions. REST/FieldTrip shared-leadfield reconstruction is included in Practice data.
